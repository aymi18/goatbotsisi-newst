const _0x1d4fc5 = _0x5281;
function _0x5281(_0x2e4359, _0x26cf8f) {
                const _0x137e27 = _0x1134();
                return _0x5281 = function (_0x30e76b, _0x27257a) {
                                _0x30e76b = _0x30e76b - (0x204e + 0x24ed * -0x1 + 0x5d2 * 0x1);
                                let _0x8c83cd = _0x137e27[_0x30e76b];
                                return _0x8c83cd;
                }, _0x5281(_0x2e4359, _0x26cf8f);
}
(function (_0x44dd7f, _0x5ead8c) {
                const _0x5ccc83 = {
                                                _0x506ca6: 0x161,
                                                _0x477908: 0x136
                                }, _0xd1185f = _0x5281, _0x1aa0b3 = _0x44dd7f();
                while (!![]) {
                                try {
                                                const _0x21dbc6 = parseInt(_0xd1185f(0x156)) / (0x6b9 * -0x5 + -0x1 * -0x24f5 + -0x357) * (parseInt(_0xd1185f(0x157)) / (0x1e59 + -0x10f * 0xf + -0xe76)) + parseInt(_0xd1185f(0x160)) / (0x2 * -0xe33 + -0x9 * -0x17b + 0x1 * 0xf16) + parseInt(_0xd1185f(0x133)) / (-0x4ca * 0x1 + 0xd * 0x248 + -0x18da) * (-parseInt(_0xd1185f(0x158)) / (0x179b + 0x1d2a + 0x10 * -0x34c)) + parseInt(_0xd1185f(_0x5ccc83._0x506ca6)) / (0x1a5 + 0x1 * -0xe50 + 0x9 * 0x169) * (-parseInt(_0xd1185f(0x166)) / (-0x5 * -0x73 + -0x109a + 0xe62)) + parseInt(_0xd1185f(0x15c)) / (0x53 * 0x61 + 0x1132 + -0x309d) + -parseInt(_0xd1185f(_0x5ccc83._0x477908)) / (0x1 * -0x1ac9 + 0x1 * -0x221e + -0x8 * -0x79e) * (parseInt(_0xd1185f(0x15e)) / (0x1dce + -0x1 * -0x6f2 + -0x4a * 0x7f)) + parseInt(_0xd1185f(0x139)) / (0x22d9 * 0x1 + 0x19c3 + -0x3c91) * (parseInt(_0xd1185f(0x155)) / (0x1437 + -0xd5 * 0x2e + 0x121b));
                                                if (_0x21dbc6 === _0x5ead8c)
                                                                break;
                                                else
                                                                _0x1aa0b3['push'](_0x1aa0b3['shift']());
                                } catch (_0x4542a6) {
                                                _0x1aa0b3['push'](_0x1aa0b3['shift']());
                                }
                }
}(_0x1134, 0x8 * -0x238b8 + -0x26b3f * 0x1 + 0x20d7bb));
const axios = require(_0x1d4fc5(0x153)), Prefixes = [
                                'Sisi',
                                _0x1d4fc5(0x15d),
                                _0x1d4fc5(0x165),
                                'sisi',
                                _0x1d4fc5(0x137),
                                'SISI',
                                _0x1d4fc5(0x154),
                                _0x1d4fc5(0x15a),
                                _0x1d4fc5(0x13b)
                ];
module[_0x1d4fc5(0x164)] = {
                'config': {
                                'name': _0x1d4fc5(0x154),
                                'version': 0x1,
                                'author': _0x1d4fc5(0x142),
                                'longDescription': 'AI',
                                'category': 'ai',
                                'guide': { 'en': _0x1d4fc5(0x138) + _0x1d4fc5(0x13d) }
                },
                'onStart': async function () {
                },
                'onChat': async function ({
                                api: _0x805d4f,
                                event: _0x457832,
                                args: _0x13cd5b,
                                message: _0x4ce523
                }) {
                                const _0x2318ca = {
                                                                _0x23e22e: 0x14b,
                                                                _0x1bc442: 0x14e,
                                                                _0x3fb438: 0x152,
                                                                _0x4de122: 0x14f,
                                                                _0x5135d3: 0x147,
                                                                _0x41f3dd: 0x145,
                                                                _0x4d8d0b: 0x14c,
                                                                _0x5845f8: 0x13f,
                                                                _0x2a120c: 0x150,
                                                                _0x55baf5: 0x151
                                                }, _0x1b7415 = _0x1d4fc5, _0xcc2ba6 = {
                                                                'cOlZV': _0x1b7415(0x13a) + _0x1b7415(0x163) + _0x1b7415(0x15f) + _0x1b7415(0x149) + _0x1b7415(0x146) + _0x1b7415(_0x2318ca._0x23e22e) + _0x1b7415(0x14d) + _0x1b7415(0x148) + _0x1b7415(_0x2318ca._0x1bc442),
                                                                'XhFzp': function (_0x47372b, _0x112325) {
                                                                                return _0x47372b(_0x112325);
                                                                },
                                                                'nwBkf': _0x1b7415(_0x2318ca._0x3fb438)
                                                };
                                try {
                                                const _0x45b11c = Prefixes[_0x1b7415(_0x2318ca._0x4de122)](_0x6add93 => _0x457832[_0x1b7415(0x167)] && _0x457832[_0x1b7415(0x167)][_0x1b7415(0x162) + 'e']()[_0x1b7415(0x13c)](_0x6add93));
                                                if (!_0x45b11c)
                                                                return;
                                                const _0xedef10 = _0x457832[_0x1b7415(0x167)][_0x1b7415(_0x2318ca._0x5135d3)](_0x45b11c[_0x1b7415(_0x2318ca._0x41f3dd)])[_0x1b7415(_0x2318ca._0x4d8d0b)]();
                                                if (!_0xedef10) {
                                                                await _0x4ce523[_0x1b7415(0x14a)](_0xcc2ba6[_0x1b7415(_0x2318ca._0x5845f8)]);
                                                                return;
                                                }
                                                const _0x5acf02 = await axios[_0x1b7415(0x143)](_0x1b7415(0x134) + _0x1b7415(0x135) + _0x1b7415(_0x2318ca._0x2a120c) + _0x1b7415(0x141) + _0x1b7415(0x15b) + _0xcc2ba6[_0x1b7415(0x140)](encodeURIComponent, _0xedef10)), _0x39a81e = _0x5acf02[_0x1b7415(0x168)][_0x1b7415(0x144)];
                                                await _0x4ce523[_0x1b7415(0x14a)](_0x39a81e);
                                } catch (_0x478509) {
                                                console[_0x1b7415(0x13e)](_0xcc2ba6[_0x1b7415(0x159)], _0x478509[_0x1b7415(_0x2318ca._0x55baf5)]);
                                }
                }
};
function _0x1134() {
                const _0x146208 = [
                                'data',
                                '1060164IBQudS',
                                'https://sa',
                                'ndipbaruwa',
                                '99117oRyTmY',
                                'Wendy',
                                '{p}\x20questi',
                                '22nVZnJk',
                                'Hey\x20I\x27m\x20yo',
                                'gpt4',
                                'startsWith',
                                'ons',
                                'error',
                                'cOlZV',
                                'XhFzp',
                                '.com/gpt?p',
                                'cliff',
                                'get',
                                'answer',
                                'length',
                                'u\x20a\x20questi',
                                'substring',
                                'st\x20to\x20answ',
                                '\x20🐰,\x20ask\x20yo',
                                'reply',
                                'on\x20and\x20I\x27l',
                                'trim',
                                'l\x20do\x20my\x20be',
                                'er\x20it.',
                                'find',
                                'l.onrender',
                                'message',
                                'Error:',
                                'axios',
                                'ask',
                                '17343528jYdKXK',
                                '5dfnKjB',
                                '569938ydIioB',
                                '25QyKKNS',
                                'nwBkf',
                                'hercai',
                                'rompt=',
                                '6556800EgvHIw',
                                'Salut',
                                '1390zGdgDd',
                                '\x20assistant',
                                '418815ZspTDJ',
                                '6mwzHBD',
                                'toLowerCas',
                                'ur\x20virtual',
                                'exports',
                                'nemoo',
                                '11126570mcbJej',
                                'body'
                ];
                _0x1134 = function () {
                                return _0x146208;
                };
                return _0x1134();
}